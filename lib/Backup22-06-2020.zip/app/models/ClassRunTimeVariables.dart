
import 'package:flutter/material.dart';

String paramurltestevelocidade;
String cor;
String corFonteS;
Colors corFonte;
List preCadastros; 
String paramurlcontratoscm;
String paramurlcontatowhats;
String paramsiteprovedor;
String parammsgprecadastro;
double paramlogotipomarginright;
double paramlogotipomarginleft;
String playerId;
String corFundoLogoTipoExibir;
Color corFundoLogoTipo;
String corFundoBackgroundExibir;
Color corFundoBackground;
Color corfontebuttonhome;
Color corfontehome;
String imagemFundoExibir;
String imagemFundo;
String paymentCardcredit;