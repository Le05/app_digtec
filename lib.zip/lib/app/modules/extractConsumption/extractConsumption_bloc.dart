import 'package:bloc_pattern/bloc_pattern.dart';

class ExtractConsumptionBloc extends BlocBase {

  @override
  void dispose() {
    super.dispose();
  }
}
