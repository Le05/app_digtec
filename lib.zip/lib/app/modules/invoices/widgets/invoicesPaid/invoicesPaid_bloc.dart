import 'package:bloc_pattern/bloc_pattern.dart';

class InvoicesPaidBloc extends BlocBase {
  

  @override
  void dispose() {
    super.dispose();
  }
}
