import 'package:flutter/material.dart';
import 'package:franet/app/app_module.dart';

void main() => runApp(AppModule());
